let DefaultServerConfig = {
    domain: 'audiocodes.com',
    addresses: ['wss://webrtclab.audiocodes.com'],
    iceServers: ['74.125.140.127:19302', '74.125.143.127:19302'],
    version: '9-Feb-2020'
}