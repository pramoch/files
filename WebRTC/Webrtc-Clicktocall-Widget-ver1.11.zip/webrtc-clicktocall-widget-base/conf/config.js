let c2c_serverConfig = {
    domain: 'example.com',                // AudioCodes SBC domain name, used to build SIP headers From/To
    addresses: ['wss://sbc.example.com'], // AudioCodes SBC secure web socket address (can be multiple)
    iceServers: []                        // Addresses for STUN servers. Can be empty
};

let c2c_config = {
    call: 'JohnDoe', // Call to this user name (or phone number).
    caller: 'Anonymous', // Caller user name (One word according SIP RFC 3261). 
    callerDN: 'Anonymous', // Caller display name (words sequence).
    messageDisplayTime: 5, // A message will be displayed during this time (seconds).
    restoreCallMaxDelay: 20 // After page reloading, call can be restored within the time interval (seconds).
};